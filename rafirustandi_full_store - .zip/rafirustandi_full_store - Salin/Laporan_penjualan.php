<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

include 'koneksi.php';
include 'header.php';

// Query contoh: hitung total transaksi per tanggal
$sql = "SELECT DATE(tanggal) as tgl, COUNT(*) as total_transaksi, SUM(total_harga) as total_penjualan 
        FROM transaksi GROUP BY DATE(tanggal) ORDER BY tgl DESC";
$result = $koneksi->query($sql);
?>

<div class="max-w-7xl mx-auto mt-10 p-6 bg-white rounded shadow">
    <h1 class="text-3xl font-bold mb-6">Laporan Penjualan Harian</h1>

    <table class="w-full table-auto border-collapse border border-gray-300">
        <thead>
            <tr class="bg-gray-100">
                <th class="border border-gray-300 px-4 py-2">Tanggal</th>
                <th class="border border-gray-300 px-4 py-2">Total Transaksi</th>
                <th class="border border-gray-300 px-4 py-2">Total Penjualan</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td class="border border-gray-300 px-4 py-2"><?= htmlspecialchars($row['tgl']) ?></td>
                <td class="border border-gray-300 px-4 py-2 text-center"><?= $row['total_transaksi'] ?></td>
                <td class="border border-gray-300 px-4 py-2">Rp <?= number_format($row['total_penjualan'], 0, ',', '.') ?></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php include 'footer.php'; ?>
