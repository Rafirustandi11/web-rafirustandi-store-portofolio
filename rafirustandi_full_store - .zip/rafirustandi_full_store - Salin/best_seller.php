<?php
session_start();
include 'koneksi.php';

$kategori = 'best_seller';

$stmt = $koneksi->prepare("SELECT * FROM produk WHERE kategori = ?");
$stmt->bind_param("s", $kategori);
$stmt->execute();
$result = $stmt->get_result();

include 'header.php';
?>

<div class="max-w-7xl mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-6">Best Seller</h1>

    <?php if ($result->num_rows > 0): ?>
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            <?php while ($produk = $result->fetch_assoc()): ?>
                <div class="border rounded shadow hover:shadow-lg transition p-4">
                    <img src="uploads/<?= htmlspecialchars($produk['gambar']) ?>" alt="<?= htmlspecialchars($produk['nama']) ?>"
                         class="w-full h-48 object-cover rounded mb-4" />
                    <h2 class="text-xl font-semibold"><?= htmlspecialchars($produk['nama']) ?></h2>
                    <p class="text-indigo-600 font-bold mt-2">Rp <?= number_format($produk['harga'], 2, ',', '.') ?></p>
                    <a href="detail_produk.php?id=<?= $produk['id'] ?>" 
                       class="inline-block mt-3 px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700">Detail</a>
                </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <p class="text-gray-600">Belum ada produk Best Seller.</p>
    <?php endif; ?>
</div>

<?php include 'footer.php'; ?>
