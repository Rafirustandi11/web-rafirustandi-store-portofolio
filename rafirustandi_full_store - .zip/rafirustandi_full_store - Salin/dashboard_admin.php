<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}
?>

<?php include 'header.php'; ?>

<div class="max-w-5xl mx-auto mt-10 p-6 bg-white rounded shadow-md">
    <h1 class="text-3xl font-bold text-gray-800 mb-6">Dashboard Admin</h1>

    <p class="mb-4 text-gray-600">
        Selamat datang, <span class="font-semibold"><?= htmlspecialchars($_SESSION['username']) ?></span>! 
        Di sini Anda dapat mengelola produk parfum, melihat laporan, dan mengatur website.
    </p>

    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
        <a href="tambah_produk.php" 
           class="block bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-4 rounded text-center shadow">
           Tambah Produk Baru
        </a>

        <a href="produk_list.php" 
           class="block bg-gray-200 hover:bg-gray-300 text-gray-800 font-semibold py-4 rounded text-center shadow">
           Lihat Daftar Produk
        </a>

        <a href="laporan_penjualan.php" 
           class="block bg-green-600 hover:bg-green-700 text-white font-semibold py-4 rounded text-center shadow">
           Laporan Penjualan
        </a>

        <a href="pengaturan_website.php" 
           class="block bg-yellow-500 hover:bg-yellow-600 text-white font-semibold py-4 rounded text-center shadow">
           Pengaturan Website
        </a>
    </div>
</div>

<?php include 'footer.php'; ?>
