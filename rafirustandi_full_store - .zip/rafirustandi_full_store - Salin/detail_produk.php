<?php
session_start();
include 'koneksi.php';
include 'header.php';

if (!isset($_GET['id'])) {
    echo "<p class='text-red-500 text-center mt-10'>Produk tidak ditemukan.</p>";
    include 'footer.php';
    exit();
}

$id = intval($_GET['id']);
$stmt = $koneksi->prepare("SELECT * FROM produk WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "<p class='text-red-500 text-center mt-10'>Produk tidak ditemukan.</p>";
    include 'footer.php';
    exit();
}

$produk = $result->fetch_assoc();
?>

<div class="max-w-5xl mx-auto mt-10 p-6 bg-white rounded shadow">
    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
        <!-- Gambar Produk -->
        <div>
            <img src="uploads/<?= htmlspecialchars($produk['gambar']) ?>" alt="<?= htmlspecialchars($produk['nama']) ?>" class="w-full rounded shadow">
        </div>

        <!-- Info Produk -->
        <div>
            <h1 class="text-3xl font-bold mb-4"><?= htmlspecialchars($produk['nama']) ?></h1>
            <p class="text-gray-700 text-lg mb-2">Kategori: <strong><?= htmlspecialchars($produk['kategori']) ?></strong></p>
            <p class="text-indigo-600 text-2xl font-semibold mb-4">Rp <?= number_format($produk['harga'], 2, ',', '.') ?></p>
         <!-- Deskripsi Produk -->
<div class="mt-6">
    <h2 class="text-xl font-semibold mb-2">Deskripsi Produk</h2>
    <p class="text-gray-700"><?= nl2br(htmlspecialchars($produk['deskripsi'])) ?></p>
</div>

         <!-- Note Parfum -->
<div class="mt-6">
    <h2 class="text-xl font-semibold mb-2">Aroma Parfum</h2>
    <p><span class="font-medium">Top Note:</span> <?= htmlspecialchars($produk['top_note']) ?></p>
    <p><span class="font-medium">Middle Note:</span> <?= htmlspecialchars($produk['middle_note']) ?></p>
    <p><span class="font-medium">Base Note:</span> <?= htmlspecialchars($produk['base_note']) ?></p>
</div>
   

<form action="tambah_keranjang.php" method="post">
  <input type="hidden" name="id" value="<?= $produk['id']; ?>">
  <label>Jumlah:</label>
  <input type="number" name="jumlah" value="1" min="1" class="border px-2 py-1 rounded w-20">
  <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Tambah ke Keranjang</button>
</form>

        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
