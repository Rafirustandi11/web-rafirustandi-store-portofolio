<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

include 'koneksi.php';

$id = $_GET['id'] ?? null;
if (!$id) {
    header("Location: produk_list.php");
    exit();
}

$error = '';

// Ambil data produk yang mau diedit
$stmt = $koneksi->prepare("SELECT * FROM produk WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    header("Location: produk_list.php");
    exit();
}
$row = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = $_POST['nama'] ?? '';
    $harga = $_POST['harga'] ?? '';
    $kategori = $_POST['kategori'] ?? '';
    $gambar = $row['gambar']; // default tetap gambar lama

    // Upload gambar baru jika ada
    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] === 0) {
        $upload_dir = 'uploads/';
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);

        $new_gambar = basename($_FILES['gambar']['name']);
        $target_file = $upload_dir . $new_gambar;

        if (move_uploaded_file($_FILES['gambar']['tmp_name'], $target_file)) {
            $gambar = $new_gambar;
        } else {
            $error = "Gagal mengupload gambar baru.";
        }
    }

    if (!$error) {
        $stmt = $koneksi->prepare("UPDATE produk SET nama = ?, harga = ?, kategori = ?, gambar = ? WHERE id = ?");
        $stmt->bind_param("sissi", $nama, $harga, $kategori, $gambar, $id);

        if ($stmt->execute()) {
            header("Location: produk_list.php");
            exit();
        } else {
            $error = "Gagal mengupdate data produk.";
        }
    }
}
?>

<?php include 'header.php'; ?>

<div class="max-w-4xl mx-auto mt-10 p-6 bg-white rounded shadow">
    <h1 class="text-2xl font-bold mb-6">Edit Produk</h1>

    <?php if ($error): ?>
        <div class="mb-4 p-3 bg-red-100 text-red-700 rounded"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form action="" method="POST" enctype="multipart/form-data" class="space-y-4">
        <div>
            <label for="nama" class="block font-semibold mb-1">Nama Produk</label>
            <input type="text" name="nama" id="nama" required
                   class="border rounded px-3 py-2 w-full" value="<?= htmlspecialchars($_POST['nama'] ?? $row['nama']) ?>">
        </div>

        <div>
            <label for="harga" class="block font-semibold mb-1">Harga (Rp)</label>
            <input type="number" name="harga" id="harga" required min="0"
                   class="border rounded px-3 py-2 w-full" value="<?= htmlspecialchars($_POST['harga'] ?? $row['harga']) ?>">
        </div>

        <div>
            <label for="kategori" class="block font-semibold mb-1">Kategori</label>
            <select name="kategori" id="kategori" required class="border rounded px-3 py-2 w-full">
                <?php
                $categories = ['beranda' => 'Beranda', 'best_seller' => 'Best Seller', 'diskon' => 'Diskon', 'pria' => 'Pria', 'wanita' => 'Wanita'];
                $selected_cat = $_POST['kategori'] ?? $row['kategori'];
                foreach ($categories as $key => $label) {
                    $selected = ($selected_cat == $key) ? 'selected' : '';
                    echo "<option value='$key' $selected>$label</option>";
                }
                ?>
            </select>
        </div>
<!-- Deskripsi Produk -->
<label for="deskripsi" class="block text-sm font-medium text-gray-700 mb-1">Deskripsi Produk</label>
<textarea name="deskripsi" id="deskripsi" rows="4" class="w-full p-2 border border-gray-300 rounded mb-4"><?= isset($produk['deskripsi']) ? htmlspecialchars($produk['deskripsi']) : '' ?></textarea>
<label for="top_note" class="block text-sm font-medium text-gray-700 mb-1">Top Note</label>
<input type="text" name="top_note" id="top_note" class="w-full p-2 border border-gray-300 rounded mb-4" value="<?= isset($produk['top_note']) ? htmlspecialchars($produk['top_note']) : '' ?>">

<label for="middle_note" class="block text-sm font-medium text-gray-700 mb-1">Middle Note</label>
<input type="text" name="middle_note" id="middle_note" class="w-full p-2 border border-gray-300 rounded mb-4" value="<?= isset($produk['middle_note']) ? htmlspecialchars($produk['middle_note']) : '' ?>">

<label for="base_note" class="block text-sm font-medium text-gray-700 mb-1">Base Note</label>
<input type="text" name="base_note" id="base_note" class="w-full p-2 border border-gray-300 rounded mb-4" value="<?= isset($produk['base_note']) ? htmlspecialchars($produk['base_note']) : '' ?>">

        <div>
            <label for="gambar" class="block font-semibold mb-1">Gambar Produk</label>
            <input type="file" name="gambar" id="gambar" accept="image/*" class="w-full" />
            <?php if ($row['gambar']): ?>
                <img src="uploads/<?= htmlspecialchars($row['gambar']) ?>" alt="Gambar Produk" class="mt-2 max-h-40" />
            <?php endif; ?>
        </div>

        <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-6 py-2 rounded">
            Update Produk
        </button>
    </form>
</div>

<?php include 'footer.php'; ?>
