<?php
session_start();
$id = intval($_GET['id']);
unset($_SESSION['keranjang'][$id]);
header("Location: keranjang.php");
exit();
