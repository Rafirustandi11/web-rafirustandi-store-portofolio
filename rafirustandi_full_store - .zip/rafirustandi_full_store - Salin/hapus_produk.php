<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

include 'koneksi.php';

if (!isset($_GET['id'])) {
    header("Location: produk_list.php");
    exit();
}

$id = intval($_GET['id']);

// Hapus produk
$stmt = $koneksi->prepare("DELETE FROM produk WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();

header("Location: produk_list.php");
exit();
