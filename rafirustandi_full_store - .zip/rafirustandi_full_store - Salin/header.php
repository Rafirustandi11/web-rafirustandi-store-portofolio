<?php
// Mulai session hanya jika belum dimulai
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Buffering agar aman pakai header()
ob_start();

// Informasi login
$is_admin = isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
$cart_count = isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Parfum Timteng Store</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-50">
    <nav class="bg-white shadow-md">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16 items-center">
                <!-- Logo -->
                <a href="index.php" class="text-2xl font-bold text-gray-800">
                    graciemots Store
                    <?php if ($is_admin) echo '<span class="text-red-600 ml-2 font-semibold">(Admin)</span>'; ?>
                </a>

                <!-- Menu Desktop -->
                <div class="hidden md:flex space-x-8">
                    <a href="index.php" class="text-gray-700 hover:text-indigo-600 font-medium">Beranda</a>
                    <a href="pria.php" class="text-gray-700 hover:text-indigo-600 font-medium">Parfum Pria</a>
                    <a href="wanita.php" class="text-gray-700 hover:text-indigo-600 font-medium">Parfum Wanita</a>
                    <a href="best_seller.php" class="text-gray-700 hover:text-indigo-600 font-medium">Best Seller</a>
                    <a href="diskon.php" class="text-gray-700 hover:text-indigo-600 font-medium">Diskon</a>

                    <?php if ($is_admin): ?>
                        <a href="dashboard_admin.php" class="text-red-600 hover:text-red-800 font-semibold">Admin Panel</a>
                    <?php endif; ?>
                </div>

                <!-- Kanan -->
                <div class="flex items-center space-x-6">
                    <!-- Keranjang -->
                    <a href="keranjang.php" class="relative text-gray-700 hover:text-indigo-600">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round" viewBox="0 0 24 24">
                            <circle cx="9" cy="21" r="1" />
                            <circle cx="20" cy="21" r="1" />
                            <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" />
                        </svg>
                        <?php if($cart_count > 0): ?>
                            <span class="absolute top-0 right-0 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-white bg-red-600 rounded-full transform translate-x-1/2 -translate-y-1/2">
                                <?= $cart_count ?>
                            </span>
                        <?php endif; ?>
                    </a>

                    <!-- Login/Logout -->
                    <?php if (isset($_SESSION['username'])): ?>
                        <a href="logout.php"
                            class="text-gray-700 hover:text-indigo-600 font-medium border border-indigo-600 px-3 py-1 rounded-md hover:bg-indigo-600 hover:text-white transition">
                            Logout (<?= htmlspecialchars($_SESSION['username']) ?>)
                        </a>
                    <?php else: ?>
                        <a href="login.php"
                            class="text-gray-700 hover:text-indigo-600 font-medium border border-indigo-600 px-3 py-1 rounded-md hover:bg-indigo-600 hover:text-white transition">
                            Login
                        </a>
                    <?php endif; ?>
                </div>

                <!-- Mobile Toggle -->
                <div class="md:hidden flex items-center">
                    <button id="mobile-menu-button" class="text-gray-700 focus:outline-none">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2"
                             stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
                            <path d="M4 6h16M4 12h16M4 18h16" />
                        </svg>
                    </button>
                </div>
            </div>
        </div>

        <!-- Menu Mobile -->
        <div id="mobile-menu" class="hidden md:hidden px-4 pt-2 pb-4 space-y-1 bg-white border-t border-gray-200">
            <a href="index.php" class="block text-gray-700 hover:text-indigo-600 font-medium">Beranda</a>
            <a href="pria.php" class="block text-gray-700 hover:text-indigo-600 font-medium">Parfum Pria</a>
            <a href="wanita.php" class="block text-gray-700 hover:text-indigo-600 font-medium">Parfum Wanita</a>
            <a href="best_seller.php" class="block text-gray-700 hover:text-indigo-600 font-medium">Best Seller</a>
            <a href="diskon.php" class="block text-gray-700 hover:text-indigo-600 font-medium">Diskon</a>
            <?php if ($is_admin): ?>
                <a href="tambah_produk.php" class="block text-red-600 hover:text-red-800 font-semibold">Tambah Produk</a>
            <?php endif; ?>
        </div>
    </nav>

    <script>
        document.getElementById('mobile-menu-button').addEventListener('click', function () {
            const menu = document.getElementById('mobile-menu');
            menu.classList.toggle('hidden');
        });
    </script>
