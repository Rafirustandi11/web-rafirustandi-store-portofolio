<?php
session_start();
include 'koneksi.php';

$total_item = 0;
if (isset($_SESSION['keranjang']) && is_array($_SESSION['keranjang'])) {
    $total_item = array_sum($_SESSION['keranjang']);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Graciemots Store</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
function tambahKeKeranjang(idProduk) {
  fetch('tambah_keranjang.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: 'id_produk=' + encodeURIComponent(idProduk) + '&jumlah=1'
  })
  .then(response => response.json())
  .then(data => {
    alert(data.message);

    if (data.status === 'success') {
      const badge = document.getElementById('badgeKeranjang');
      const currentCount = parseInt(badge.textContent) || 0;
      badge.textContent = currentCount + 1;
    }
  })
  .catch(error => {
    console.error('Gagal:', error);
    alert('Terjadi kesalahan saat menambahkan ke keranjang.');
  });
}
</script>



<!-- NAVBAR -->
<nav class="bg-white shadow-md sticky top-0 z-50">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="flex justify-between h-16 items-center">
      <a href="index.php" class="text-2xl font-bold text-gray-800">Graciemots Store</a>

      <div class="hidden md:flex space-x-8">
        <a href="index.php" class="text-gray-700 hover:text-indigo-600 font-medium">Beranda</a>
        <a href="pria.php" class="text-gray-700 hover:text-indigo-600 font-medium">Parfum Pria</a>
        <a href="wanita.php" class="text-gray-700 hover:text-indigo-600 font-medium">Parfum Wanita</a>
        <a href="best_seller.php" class="text-gray-700 hover:text-indigo-600 font-medium">Best Seller</a>
        <a href="diskon.php" class="text-gray-700 hover:text-indigo-600 font-medium">Diskon</a>
      </div>

      <div class="flex items-center space-x-7">
        <a href="keranjang.php" class="relative text-gray-700 hover:text-indigo-600">
          <svg class="w-7 h-7" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path d="M3 3h2l.4 2M7 13h10l4-8H5.4" stroke-linecap="round" stroke-linejoin="round"/>
            <circle cx="9" cy="21" r="1" />
            <circle cx="20" cy="21" r="1" />
          </svg>
          <span id="badgeKeranjang" class="absolute -top-2 -right-2 bg-red-600 text-white text-xs font-semibold rounded-full w-5 h-5 flex items-center justify-center shadow">
            <?= $total_item ?>
          </span>
        </a>

        <a href="login.php" class="border border-indigo-600 px-3 py-1 rounded hover:bg-indigo-600 hover:text-white transition">
          Login
        </a>
      </div>
    </div>
  </div>
</nav>

<!-- HERO SECTION -->
<section class="relative">
  <img src="uploads/Parfum-Arab.jpg" alt="Parfum Banner"
       class="w-full h-[450px] object-cover brightness-75 rounded-b-xl">

  <div class="absolute inset-0 flex flex-col items-center justify-center text-white text-center px-4">
    <h1 class="text-4xl font-bold mb-3 drop-shadow">Parfum Unggulan Timur Tengah</h1>
    <p class="text-lg mb-5 drop-shadow">Aroma mewah dan eksotis untuk kesan yang tak terlupakan.</p>
    <a href="best_seller.php"
       class="bg-indigo-600 hover:bg-indigo-700 px-6 py-2 rounded font-semibold transition">
      Lihat Best Seller
    </a>
  </div>
</section>

<!-- KATEGORI UNGGULAN -->
<section class="py-12 bg-gray-50">
  <div class="max-w-6xl mx-auto px-4 text-center">
    <h2 class="text-2xl font-bold text-gray-800 mb-8">Kategori Unggulan</h2>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-6">
      <a href="pria.php" class="p-6 bg-white rounded-lg shadow hover:shadow-md transition">
        <img src="uploads/police-be-bad-guy-man.jpg" alt="" class="w-10 h-10 mx-auto mb-2">
        <p class="font-medium">Parfum Pria</p>
      </a>
      <a href="wanita.php" class="p-6 bg-white rounded-lg shadow hover:shadow-md transition">
        <img src="uploads/parfum wanita 1.jpeg" alt="" class="w-10 h-10 mx-auto mb-2">
        <p class="font-medium">Parfum Wanita</p>
      </a>
      <a href="diskon.php" class="p-6 bg-white rounded-lg shadow hover:shadow-md transition">
        <img src="uploads/parfum wanita 7.jpeg" alt="" class="w-10 h-10 mx-auto mb-2">
        <p class="font-medium">Diskon</p>
      </a>
      <a href="best_seller.php" class="p-6 bg-white rounded-lg shadow hover:shadow-md transition">
        <img src="uploads/Reebok-statement-blue-for-him.jpg" alt="" class="w-10 h-10 mx-auto mb-2">
        <p class="font-medium">Best Seller</p>
      </a>
    </div>
  </div>
</section>

<!-- PRODUK UNGGULAN -->
<section class="py-12">
  <div class="max-w-6xl mx-auto px-4 text-center">
    <h2 class="text-2xl font-bold mb-6 text-gray-800">Produk Unggulan</h2>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
      <?php
      $produk = $koneksi->query("SELECT * FROM produk LIMIT 6");
      while ($row = $produk->fetch_assoc()):
      ?>
        <div class="bg-white rounded-lg shadow p-6 text-left">
          <img src="uploads/<?= htmlspecialchars($row['gambar']) ?>" alt="<?= htmlspecialchars($row['nama']) ?>" class="h-48 w-full object-cover rounded mb-4">
          <h3 class="text-lg font-bold text-gray-800"><?= htmlspecialchars($row['nama']) ?></h3>
          <p class="text-indigo-600 font-semibold mb-2">Rp <?= number_format($row['harga'], 0, ',', '.') ?></p>
          <button onclick="tambahKeKeranjang(<?= $row['id'] ?>)" class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded mt-2 w-full">Tambah ke Keranjang</button>
        </div>
      <?php endwhile; ?>
    </div>
  </div>
</section>

<!-- TESTIMONI -->
<section class="py-12 bg-white">
  <div class="max-w-6xl mx-auto px-4 text-center">
    <h2 class="text-2xl font-bold text-gray-800 mb-6">Apa Kata Pelanggan</h2>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div class="bg-gray-50 p-6 rounded-lg shadow">
        <p class="text-sm italic">“Aromanya luar biasa! Setiap orang yang saya temui menanyakan parfumnya.”</p>
        <div class="mt-4 font-semibold text-indigo-600">– Rina, Jakarta</div>
      </div>
      <div class="bg-gray-50 p-6 rounded-lg shadow">
        <p class="text-sm italic">“Parfum dari Graciemots benar-benar berkualitas. Worth every rupiah!”</p>
        <div class="mt-4 font-semibold text-indigo-600">– Ahmad, Surabaya</div>
      </div>
      <div class="bg-gray-50 p-6 rounded-lg shadow">
        <p class="text-sm italic">“Pelayanan cepat, packaging elegan, dan aromanya tahan lama.”</p>
        <div class="mt-4 font-semibold text-indigo-600">– Dewi, Bandung</div>
      </div>
    </div>
  </div>
</section>

<!-- FOOTER -->
<footer class="bg-gray-800 text-white py-6">
  <div class="max-w-7xl mx-auto px-4 text-center">
    <p>&copy; <?= date('Y') ?> Graciemots Store. All rights reserved.</p>
    <p class="text-sm text-gray-400">Parfum Eksklusif Timur Tengah • Elegan • Mewah</p>
  </div>
</footer>

</body>
</html>
