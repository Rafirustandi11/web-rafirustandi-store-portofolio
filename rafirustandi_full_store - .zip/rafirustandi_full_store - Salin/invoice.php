<?php
include 'koneksi.php';

if (!isset($_GET['id'])) {
    die('ID pembelian tidak ditemukan.');
}

$id = intval($_GET['id']);

// Ambil data pembelian
$query = $koneksi->prepare("SELECT * FROM pembelian WHERE id_pembelian = ?");
$query->bind_param("i", $id);
$query->execute();
$result = $query->get_result();
$pembelian = $result->fetch_assoc();

if (!$pembelian) {
    die('Data pembelian tidak ditemukan.');
}

// Ambil produk terkait pembelian
$query_produk = $koneksi->prepare("SELECT * FROM pembelian_produk WHERE id_pembelian = ?");
$query_produk->bind_param("i", $id);
$query_produk->execute();
$result_produk = $query_produk->get_result();

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <title>Invoice Pesanan #<?= $id ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @media print {
            .no-print { display: none; }
        }
    </style>
</head>
<body class="bg-gray-50 min-h-screen p-8">
    <div class="max-w-3xl mx-auto bg-white p-8 rounded shadow">
        <h1 class="text-3xl font-bold mb-6">Invoice Pesanan #<?= $id ?></h1>

        <section class="mb-6">
            <h2 class="text-xl font-semibold mb-2">Data Pembeli</h2>
            <p><strong>Nama:</strong> <?= htmlspecialchars($pembelian['nama']) ?></p>
            <p><strong>Telepon:</strong> <?= htmlspecialchars($pembelian['telepon']) ?></p>
            <p><strong>Alamat:</strong> <?= nl2br(htmlspecialchars($pembelian['alamat'])) ?></p>
            <p><strong>Metode Pembayaran:</strong> <?= htmlspecialchars($pembelian['metode']) ?></p>
            <p><strong>Tanggal:</strong> <?= htmlspecialchars($pembelian['tanggal_pembelian']) ?></p>
        </section>

        <section>
            <h2 class="text-xl font-semibold mb-4">Daftar Produk</h2>
            <table class="w-full border border-gray-300 border-collapse">
                <thead>
                    <tr class="bg-gray-100">
                        <th class="border border-gray-300 px-4 py-2 text-left">Produk</th>
                        <th class="border border-gray-300 px-4 py-2 text-right">Harga</th>
                        <th class="border border-gray-300 px-4 py-2 text-center">Jumlah</th>
                        <th class="border border-gray-300 px-4 py-2 text-right">Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $total = 0;
                    while ($row = $result_produk->fetch_assoc()):
                        $total += $row['subtotal'];
                    ?>
                    <tr>
                        <td class="border border-gray-300 px-4 py-2"><?= htmlspecialchars($row['nama_produk']) ?></td>
                        <td class="border border-gray-300 px-4 py-2 text-right">Rp <?= number_format($row['harga'], 2, ',', '.') ?></td>
                        <td class="border border-gray-300 px-4 py-2 text-center"><?= $row['jumlah'] ?></td>
                        <td class="border border-gray-300 px-4 py-2 text-right">Rp <?= number_format($row['subtotal'], 2, ',', '.') ?></td>
                    </tr>
                    <?php endwhile; ?>
                    <tr class="font-bold bg-gray-200">
                        <td colspan="3" class="border border-gray-300 px-4 py-2 text-right">Total</td>
                        <td class="border border-gray-300 px-4 py-2 text-right">Rp <?= number_format($total, 2, ',', '.') ?></td>
                    </tr>
                </tbody>
            </table>
        </section>

        <button onclick="window.print()" class="no-print mt-6 px-6 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 transition">Cetak Invoice</button>
    </div>
</body>
</html>
