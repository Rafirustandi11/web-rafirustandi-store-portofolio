<?php
session_start();
include 'koneksi.php';
include 'header.php'; // pastikan ada header yang sudah load Tailwind CSS
?>

<div class="min-h-screen bg-gray-100 py-10">
  <div class="max-w-5xl mx-auto bg-white p-8 rounded shadow">
    <h1 class="text-3xl font-bold mb-8 text-center">Keranjang Belanja</h1>

    <?php if (empty($_SESSION['keranjang'])): ?>
      <p class="text-center text-gray-600 text-lg">Keranjang Anda kosong.</p>
      <div class="text-center mt-6">
        <a href="index.php" class="inline-block bg-gray-900 text-white px-6 py-3 rounded hover:bg-gray-700 transition">Kembali ke Beranda</a>
      </div>
    <?php else: ?>
      <form method="post" action="lanjutkan_pembayaran.php">
        <table class="w-full border-collapse border border-gray-300">
          <thead>
            <tr class="bg-gray-200 text-gray-700">
              <th class="border border-gray-300 px-4 py-2">Produk</th>
              <th class="border border-gray-300 px-4 py-2">Harga</th>
              <th class="border border-gray-300 px-4 py-2">Jumlah</th>
              <th class="border border-gray-300 px-4 py-2">Total</th>
              <th class="border border-gray-300 px-4 py-2">Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $total = 0;
            foreach ($_SESSION['keranjang'] as $id => $qty):
              $id = intval($id);
              $query = $koneksi->query("SELECT * FROM produk WHERE id=$id");
              if ($query->num_rows === 0) continue;
              $data = $query->fetch_assoc();
              $sub = $data['harga'] * $qty;
              $total += $sub;
            ?>
            <tr class="text-center">
              <td class="border border-gray-300 px-4 py-2"><?php echo htmlspecialchars($data['nama']); ?></td>
              <td class="border border-gray-300 px-4 py-2">Rp <?php echo number_format($data['harga'], 2, ',', '.'); ?></td>
              <td class="border border-gray-300 px-4 py-2"><?php echo $qty; ?></td>
              <td class="border border-gray-300 px-4 py-2">Rp <?php echo number_format($sub, 2, ',', '.'); ?></td>
              <td class="border border-gray-300 px-4 py-2">
                <a href="hapus_keranjang.php?id=<?php echo $id; ?>" class="text-red-600 hover:text-red-800 font-semibold">Hapus</a>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
          <tfoot>
            <tr class="bg-gray-100 font-bold text-lg text-right">
              <td colspan="3" class="border border-gray-300 px-4 py-2">Total</td>
              <td colspan="2" class="border border-gray-300 px-4 py-2">Rp <?php echo number_format($total, 2, ',', '.'); ?></td>
          </tfoot>
        </table>

        <div class="flex justify-between mt-6">
          <a href="kosongkan_keranjang.php" class="bg-red-600 text-white px-6 py-2 rounded hover:bg-red-700 transition">Kosongkan Keranjang</a>
          <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded hover:bg-green-700 transition">Lanjutkan Pembayaran</button>
        </div>
      </form>
    <?php endif; ?>
  </div>
</div>

<?php include 'footer.php'; ?>
