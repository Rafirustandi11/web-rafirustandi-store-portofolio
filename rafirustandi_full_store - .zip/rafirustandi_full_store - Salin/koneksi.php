<?php
$koneksi = new mysqli("localhost", "root", "", "parfum_timteng");

if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}
