<?php
include 'koneksi.php';
session_start();

// Cek apakah ada keranjang di session
if (empty($_SESSION['keranjang'])) {
    echo "Keranjang belanja kosong.";
    exit;
}

// Ambil data dari form checkout
$nama     = $_POST['nama'];
$telepon  = $_POST['telepon'];
$alamat   = $_POST['alamat'];
$email    = $_POST['email'];
$metode   = $_POST['metode'];
$tanggal  = date('Y-m-d H:i:s');

// Hitung total
$total = 0;
foreach ($_SESSION['keranjang'] as $id_produk => $jumlah) {
    $query = mysqli_query($koneksi, "SELECT * FROM produk WHERE id = $id_produk");
    $data = mysqli_fetch_assoc($query);
    $subtotal = $data['harga'] * $jumlah;
    $total += $subtotal;
}

// Simpan ke tabel transaksi
$stmt = $koneksi->prepare("INSERT INTO transaksi (tanggal, NamaLengkap, NomerHP, Alamat, Metodepembayaran, Email, total_harga) VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssssd", $tanggal, $nama, $telepon, $alamat, $metode, $email, $total);
$stmt->execute();
$id_transaksi = $stmt->insert_id;

// Simpan produk ke pembelian_produk
foreach ($_SESSION['keranjang'] as $id_produk => $jumlah) {
    $query = mysqli_query($koneksi, "SELECT * FROM produk WHERE id = $id_produk");
    $data = mysqli_fetch_assoc($query);
    $nama_produk = $data['nama'];
    $harga = $data['harga'];
    $subtotal = $harga * $jumlah;

    $stmt_produk = $koneksi->prepare("INSERT INTO pembelian_produk (id_pembelian, nama_produk, harga, jumlah, subtotal) VALUES (?, ?, ?, ?, ?)");
    $stmt_produk->bind_param("isdid", $id_transaksi, $nama_produk, $harga, $jumlah, $subtotal);
    $stmt_produk->execute();
}

// Kosongkan keranjang
unset($_SESSION['keranjang']);

// Redirect ke halaman konfirmasi
header("Location: konfirmasi_pesanan.php?id=$id_transaksi");
exit;
