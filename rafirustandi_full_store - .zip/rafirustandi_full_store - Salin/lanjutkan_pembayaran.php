<?php
include 'header.php';
?>

<form method="POST" action="proses_pembayaran.php" class="max-w-xl mx-auto bg-white p-6 rounded shadow space-y-5">
  <h2 class="text-2xl font-bold text-center mb-4">Formulir Checkout</h2>

  <div>
    <label for="nama" class="block text-gray-700 font-medium mb-1">Nama Lengkap</label>
    <input type="text" id="nama" name="nama" required class="w-full border border-gray-300 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
  </div>

  <div>
    <label for="telepon" class="block text-gray-700 font-medium mb-1">No. HP</label>
    <input type="text" id="telepon" name="telepon" required class="w-full border border-gray-300 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
  </div>

  <div>
    <label for="alamat" class="block text-gray-700 font-medium mb-1">Alamat</label>
    <textarea id="alamat" name="alamat" required rows="3" class="w-full border border-gray-300 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"></textarea>
  </div>

  <div>
    <label for="email" class="block text-gray-700 font-medium mb-1">Email</label>
    <input type="email" id="email" name="email" required class="w-full border border-gray-300 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
  </div>

  <div>
    <label for="metode" class="block text-gray-700 font-medium mb-1">Metode Pembayaran</label>
    <select id="metode" name="metode" required class="w-full border border-gray-300 rounded px-4 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">
      <option value="COD">COD</option>
      <option value="Transfer Bank">Transfer Bank</option>
      <option value="QRIS">QRIS</option>
    </select>
  </div>

  <div class="text-center">
    <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded hover:bg-green-700 transition">Selesaikan Pembayaran</button>
  </div>
</form>


