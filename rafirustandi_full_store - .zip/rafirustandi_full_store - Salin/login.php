<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include 'koneksi.php';

if (isset($_POST['username']) && isset($_POST['password'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = $koneksi->prepare("SELECT * FROM admin WHERE username = ? AND password = ?");
    $query->bind_param("ss", $username, $password);
    $query->execute();
    $result = $query->get_result();

    if ($result->num_rows > 0) {
        $admin_data = $result->fetch_assoc();
        $_SESSION['username'] = $admin_data['username'];
        $_SESSION['role'] = 'admin';

        header('Location: dashboard_admin.php');
        exit();
    } else {
        $error = "Username atau password salah!";
    }
}
?>

<?php include 'header.php'; ?>

<div class="max-w-md mx-auto mt-10 p-6 bg-white rounded shadow">
    <?php if (isset($error)): ?>
        <p class="text-red-600 text-center mb-4"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>

    <form method="POST" action="">
        <label for="username" class="block font-semibold mb-1">Username:</label>
        <input type="text" name="username" id="username" required class="w-full border border-gray-300 rounded p-2 mb-4">

        <label for="password" class="block font-semibold mb-1">Password:</label>
        <input type="password" name="password" id="password" required class="w-full border border-gray-300 rounded p-2 mb-6">

        <button type="submit" class="w-full bg-indigo-600 text-white py-2 rounded hover:bg-indigo-700">
            Login
        </button>
    </form>
</div>

<?php include 'footer.php'; ?>
