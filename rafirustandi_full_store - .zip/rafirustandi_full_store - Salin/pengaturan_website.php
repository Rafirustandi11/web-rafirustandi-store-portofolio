<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

include 'koneksi.php';
include 'header.php';

// Ambil data pengaturan yang sudah ada, asumsikan hanya 1 row
$result = $koneksi->query("SELECT * FROM pengaturan_website ORDER BY id DESC LIMIT 1");
$settings = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_toko = $koneksi->real_escape_string($_POST['nama_toko']);
    $alamat = $koneksi->real_escape_string($_POST['alamat']);
    $kontak = $koneksi->real_escape_string($_POST['kontak']);
    $deskripsi = $koneksi->real_escape_string($_POST['deskripsi']);

    if ($settings) {
        // Update data
        $sql = "UPDATE pengaturan_website SET
                nama_toko='$nama_toko',
                alamat='$alamat',
                kontak='$kontak',
                deskripsi='$deskripsi',
                updated_at=NOW()
                WHERE id=" . $settings['id'];
        $koneksi->query($sql);
    } else {
        // Insert data baru
        $sql = "INSERT INTO pengaturan_website (nama_toko, alamat, kontak, deskripsi) VALUES
                ('$nama_toko', '$alamat', '$kontak', '$deskripsi')";
        $koneksi->query($sql);
    }

    // Refresh data setelah update/insert
    header("Location: pengaturan_website.php?success=1");
    exit();
}
?>

<div class="max-w-4xl mx-auto mt-10 p-6 bg-white rounded shadow">
    <h1 class="text-3xl font-bold mb-6">Pengaturan Website</h1>

    <?php if (isset($_GET['success'])): ?>
        <div class="mb-4 p-4 bg-green-100 text-green-700 rounded">
            Pengaturan berhasil disimpan.
        </div>
    <?php endif; ?>

    <form method="POST" action="pengaturan_website.php" class="space-y-6">
        <div>
            <label for="nama_toko" class="block font-semibold mb-1">Nama Toko</label>
            <input type="text" id="nama_toko" name="nama_toko" required
                class="w-full border border-gray-300 rounded px-3 py-2"
                value="<?= htmlspecialchars($settings['nama_toko'] ?? '') ?>">
        </div>

        <div>
            <label for="alamat" class="block font-semibold mb-1">Alamat</label>
            <textarea id="alamat" name="alamat" rows="3"
                class="w-full border border-gray-300 rounded px-3 py-2"><?= htmlspecialchars($settings['alamat'] ?? '') ?></textarea>
        </div>

        <div>
            <label for="kontak" class="block font-semibold mb-1">Kontak</label>
            <input type="text" id="kontak" name="kontak"
                class="w-full border border-gray-300 rounded px-3 py-2"
                value="<?= htmlspecialchars($settings['kontak'] ?? '') ?>">
        </div>

        <div>
            <label for="deskripsi" class="block font-semibold mb-1">Deskripsi Singkat</label>
            <textarea id="deskripsi" name="deskripsi" rows="4"
                class="w-full border border-gray-300 rounded px-3 py-2"><?= htmlspecialchars($settings['deskripsi'] ?? '') ?></textarea>
        </div>

        <button type="submit"
            class="bg-indigo-600 text-white px-6 py-2 rounded hover:bg-indigo-700 transition font-semibold">
            Simpan Pengaturan
        </button>
    </form>
</div>

<?php include 'footer.php'; ?>
