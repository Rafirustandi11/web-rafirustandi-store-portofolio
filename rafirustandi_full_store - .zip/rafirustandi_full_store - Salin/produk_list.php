<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

include 'koneksi.php';
include 'header.php';

// Ambil semua produk dari database
$result = $koneksi->query("SELECT * FROM produk ORDER BY id DESC");
?>

<div class="max-w-7xl mx-auto mt-10 p-6 bg-white rounded shadow">
    <h1 class="text-3xl font-bold mb-6">Daftar Produk</h1>

    <a href="tambah_produk.php" 
       class="inline-block mb-4 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-4 rounded">
       + Tambah Produk Baru
    </a>

    <table class="w-full table-auto border-collapse border border-gray-300">
        <thead>
            <tr class="bg-gray-100">
                <th class="border border-gray-300 px-4 py-2">ID</th>
                <th class="border border-gray-300 px-4 py-2">Nama Produk</th>
                <th class="border border-gray-300 px-4 py-2">Harga</th>
                <th class="border border-gray-300 px-4 py-2">Kategori</th>
                <th class="border border-gray-300 px-4 py-2">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td class="border border-gray-300 px-4 py-2 text-center"><?= htmlspecialchars($row['id']) ?></td>
                <td class="border border-gray-300 px-4 py-2"><?= htmlspecialchars($row['nama']) ?></td>
                <td class="border border-gray-300 px-4 py-2">Rp <?= number_format($row['harga'], 2, ',', '.') ?></td>
                <td class="border border-gray-300 px-4 py-2"><?= htmlspecialchars($row['kategori']) ?></td>
                <td class="border border-gray-300 px-4 py-2 text-center space-x-2">
                    <a href="edit_produk.php?id=<?= $row['id'] ?>" 
                       class="text-indigo-600 hover:underline">Edit</a>
                    <a href="hapus_produk.php?id=<?= $row['id'] ?>" 
                       onclick="return confirm('Yakin ingin menghapus produk ini?')"
                       class="text-red-600 hover:underline">Hapus</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php include 'footer.php'; ?>
