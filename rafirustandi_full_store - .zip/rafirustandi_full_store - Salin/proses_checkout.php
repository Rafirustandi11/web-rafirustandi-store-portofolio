<?php
session_start();
include 'koneksi.php';

// Fungsi untuk menampilkan alert dan redirect dengan Tailwind
function alert_redirect($message, $url) {
    echo '
    <html>
    <head>
        <script src="https://cdn.tailwindcss.com"></script>
    </head>
    <body class="flex items-center justify-center min-h-screen bg-gray-100">
        <div class="bg-white p-6 rounded shadow-lg text-center max-w-md mx-auto">
            <p class="text-red-600 font-semibold mb-4">' . htmlspecialchars($message) . '</p>
            <a href="' . $url . '" class="inline-block bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700 transition">Kembali</a>
        </div>
    </body>
    </html>
    ';
    exit();
}

// Cek apakah keranjang tidak kosong
if (empty($_SESSION['keranjang'])) {
    alert_redirect('Keranjang Anda kosong.', 'keranjang.php');
}

// Ambil data pembeli dari POST dengan htmlspecialchars untuk keamanan
$nama = htmlspecialchars($_POST['nama']);
$telepon = htmlspecialchars($_POST['telepon']);
$alamat = htmlspecialchars($_POST['alamat']);
$metode = htmlspecialchars($_POST['metode']);
$tanggal = date("Y-m-d");

// Simpan ke tabel `pembelian`
$query = "INSERT INTO pembelian (nama, telepon, alamat, metode, tanggal_pembelian, id_user) VALUES (?, ?, ?, ?, ?, ?)";
$stmt = $koneksi->prepare($query);
$stmt->bind_param("ssssss", $nama, $telepon, $alamat, $metode, $tanggal, $id_user);
$stmt->execute();

// Ambil ID pembelian terakhir
$id_pembelian = $stmt->insert_id;

// Simpan detail setiap produk dari keranjang ke tabel `pembelian_produk`
foreach ($_SESSION['keranjang'] as $id_produk => $jumlah) {
    $query_produk = $koneksi->prepare("SELECT nama, harga FROM produk WHERE id = ?");
    $query_produk->bind_param("i", $id_produk);
    $query_produk->execute();
    $result = $query_produk->get_result();
    $data_produk = $result->fetch_assoc();

    $nama_produk = $data_produk['nama'];
    $harga = $data_produk['harga'];
    $subtotal = $harga * $jumlah;

    $query_detail = "INSERT INTO pembelian_produk (id_pembelian, id_produk, nama_produk, harga, jumlah, subtotal)
                     VALUES (?, ?, ?, ?, ?, ?)";
    $stmt_detail = $koneksi->prepare($query_detail);
    $stmt_detail->bind_param("iisiii", $id_pembelian, $id_produk, $nama_produk, $harga, $jumlah, $subtotal);
    $stmt_detail->execute();
}

// Kosongkan keranjang
unset($_SESSION['keranjang']);

// Redirect ke halaman konfirmasi dengan pesan sukses
header("Location: konfirmasi_pesanan.php?id=$id_pembelian");
exit();
?>
