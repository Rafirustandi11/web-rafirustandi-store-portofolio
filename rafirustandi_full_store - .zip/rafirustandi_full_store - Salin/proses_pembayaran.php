<?php
include 'koneksi.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Ambil data dari form
  $nama     = $_POST['nama'];
  $telepon  = $_POST['telepon'];
  $alamat   = $_POST['alamat'];
  $email    = $_POST['email'];
  $metode   = $_POST['metode'];

  // Validasi: pastikan keranjang tidak kosong
  if (!isset($_SESSION['keranjang']) || count($_SESSION['keranjang']) == 0) {
    echo "<script>alert('Keranjang kosong!'); window.location='index.php';</script>";
    exit;
  }

  // Hitung total harga
  $total = 0;
  foreach ($_SESSION['keranjang'] as $id_produk => $jumlah) {
    $query = mysqli_query($koneksi, "SELECT * FROM produk WHERE id = $id_produk");
    $produk = mysqli_fetch_assoc($query);
    $total += $produk['harga'] * $jumlah;
  }

  // Simpan ke tabel transaksi
  $tanggal = date("Y-m-d"); // Format sesuai kolom `tanggal` (datetime)
  $stmt = mysqli_prepare($koneksi, "INSERT INTO transaksi (tanggal, NamaLengkap, NomerHP, Alamat, Metodepembayaran, Email, total_harga) VALUES (?, ?, ?, ?, ?, ?, ?)");
  mysqli_stmt_bind_param($stmt, "ssssssd", $tanggal, $nama, $telepon, $alamat, $metode, $email, $total);
  mysqli_stmt_execute($stmt);
  mysqli_stmt_close($stmt);

  // Kosongkan keranjang
  unset($_SESSION['keranjang']);

  echo "<script>alert('Transaksi berhasil!'); ;</script>";
  // Redirect ke konfirmasi
header("Location: konfirmasi_pesanan.php?id=$id_transaksi");
exit;
}

