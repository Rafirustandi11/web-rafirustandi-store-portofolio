<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
include 'koneksi.php';

$id_user = $_SESSION['user_id'];
$query = $koneksi->prepare("SELECT * FROM pembelian WHERE id_user = ? ORDER BY tanggal_pembelian DESC");
$query->bind_param("i", $id_user);
$query->execute();
$result = $query->get_result();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <title>Riwayat Pembelian</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 min-h-screen p-8">
    <div class="max-w-4xl mx-auto bg-white p-6 rounded shadow">
        <h1 class="text-3xl font-bold mb-6">Riwayat Pembelian</h1>

        <?php if ($result->num_rows === 0): ?>
            <p>Anda belum memiliki riwayat pembelian.</p>
        <?php else: ?>
            <table class="w-full border border-gray-300 border-collapse">
                <thead>
                    <tr class="bg-gray-100">
                        <th class="border border-gray-300 px-4 py-2">ID Pesanan</th>
                        <th class="border border-gray-300 px-4 py-2">Tanggal</th>
                        <th class="border border-gray-300 px-4 py-2">Metode</th>
                        <th class="border border-gray-300 px-4 py-2">Status</th>
                        <th class="border border-gray-300 px-4 py-2">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td class="border border-gray-300 px-4 py-2"><?= $row['id_pembelian'] ?></td>
                        <td class="border border-gray-300 px-4 py-2"><?= htmlspecialchars($row['tanggal_pembelian']) ?></td>
                        <td class="border border-gray-300 px-4 py-2"><?= htmlspecialchars($row['metode']) ?></td>
                        <td class="border border-gray-300 px-4 py-2"><?= htmlspecialchars($row['status'] ?? 'Pending') ?></td>
                        <td class="border border-gray-300 px-4 py-2">
                            <a href="invoice.php?id=<?= $row['id_pembelian'] ?>" class="text-indigo-600 hover:underline">Lihat Detail</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</body>
</html>
