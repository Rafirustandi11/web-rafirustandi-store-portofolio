function tambahKeKeranjang(id) {
    const data = new FormData();
    data.append('id', id);
  
    fetch('tambah_keranjang.php', {
      method: 'POST',
      body: data
    })
    .then(response => response.json())
    .then(result => {
      alert(result.message);
    })
    .catch(error => {
      console.error('AJAX Error:', error);
      alert('Terjadi kesalahan saat menambahkan ke keranjang.');
    });
  }
  