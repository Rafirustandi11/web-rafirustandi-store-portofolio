<?php
include 'koneksi.php';
session_start();

// Ambil ID dan jumlah dari POST (bukan GET)
$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
$jumlah = isset($_POST['jumlah']) ? intval($_POST['jumlah']) : 1;

if ($jumlah < 1) $jumlah = 1; // jumlah minimal = 1

// Cek apakah produk ada
$query = mysqli_query($koneksi, "SELECT * FROM produk WHERE id = $id");
$data = mysqli_fetch_assoc($query);

if ($data) {
    // Inisialisasi keranjang jika belum ada
    if (!isset($_SESSION['keranjang'])) {
        $_SESSION['keranjang'] = [];
    }

    // Tambahkan ke keranjang
    if (isset($_SESSION['keranjang'][$id])) {
        $_SESSION['keranjang'][$id] += $jumlah;
    } else {
        $_SESSION['keranjang'][$id] = $jumlah;
    }

    // Redirect ke halaman keranjang
    header("Location: index.php"); // sesuaikan dengan file kamu
    exit;
} else {
    echo "<script>alert('Produk tidak ditemukan'); window.history.back();</script>";
}
